﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SAT1
{
    class Solver
    {
        // Number of variables in 3SAT instance
        private const int NVARS = 100;

        // Number of clauses in 3SAT instance
        private const int NCLAUSES = 5 * NVARS;

        // 0 = all clauses have three literals
        // Larger than 0, controls probability that a clause will have
        // less than three literals.  The higher the threshold, the
        // more likely that all clauses have three literals.
        private const int SMALL_THRESHOLD = 0;

        // True: Pick next variable arbitrarily
        // False:  Pick next variable intelligently
        public const bool ARBITRARY_PICK = false;

        static void Main()
        {
            ISet<Variable> variables;
            Formula f = RandomFormula(NVARS, NCLAUSES, out variables);

            Console.WriteLine(f);

            SatSolver solver = new SatSolver(f, variables);
            if (solver.Solve())
            {
                Console.WriteLine("Solved:");
                foreach (Variable v in variables)
                {
                    Console.Write(v.Name + ": ");
                    if (v.IsTrue) Console.WriteLine("T");
                    else if (v.IsFalse) Console.WriteLine("F");
                    else Console.WriteLine("-");
                }
            }
            else
            {
                Console.WriteLine("No solution");
            }
            Console.WriteLine("Calls: " + solver.Calls);
        }

        static Formula RandomFormula(int nVars, int nClauses, out ISet<Variable> variables)
        {
            variables = new SortedSet<Variable>(Comparer<Variable>.Create((v1,v2) => v1.Name.CompareTo(v2.Name)));
            IList<Variable> vars = new List<Variable>();
            int suffixLength = (int) Math.Log10(nVars - 1) + 1;
            for (int i = 0; i < nVars; i++)
            {
                string suffix = i.ToString();
                while (suffix.Length < suffixLength)
                {
                    suffix = "0" + suffix;
                }
                vars.Add(new Variable("x" + suffix));
            }

            Random r = new Random();
            Formula f = new Formula();
            for (int i = 0; i < nClauses; i++)
            {
                Clause c = new Clause();
                int varCount = 3;
                while (varCount > 0)
                {
                    Variable v = vars[r.Next(nVars)];
                    if (c.Variables().Contains(v)) continue;
                    variables.Add(v);
                    if (r.Next(2) == 0)
                    {
                        c.AddVar(v);
                    }
                    else
                    {
                        c.AddNotVar(v);
                    }
                    varCount--;
                    if (SMALL_THRESHOLD > 0 && r.Next(SMALL_THRESHOLD) == 0) break;
                }
                f.AddClause(c);
            }
            return f;
        }
    }

    class SatSolver
    {
        // The number of times the Solve method has been called.
        public int Calls { get; private set; }

        // The formula we are trying to satisfy
        private Formula formula;

        // The variables of the formula that do not currently have a T/F value
        private ISet<Variable> unboundVariables;

        // The variables of the formula that currently have a T/F value
        private ISet<Variable> boundVariables;
        

        public SatSolver (Formula f, ISet<Variable> vars)
        {
            unboundVariables = new HashSet<Variable>(vars);
            boundVariables = new HashSet<Variable>();
            formula = f;
            Calls = 0;
        }

        /// <summary>
        /// Attempts to solve an instance of 3SAT.  Returns true if successful, leaving the variables bound
        /// in the way that led to success.
        /// </summary>
        public bool Solve()
        {
            // If there are no clauses in the formula, we've found a solution
            Calls++;
            if (formula.IsEmpty()) return true;

            // Pick an unbound variable to try
            Variable v;
            if (Solver.ARBITRARY_PICK)
            {
                v = unboundVariables.First();
            }
            else {
                v = formula.ChooseVariable();
            }
            unboundVariables.Remove(v);
            boundVariables.Add(v);

            // Make the variable true and see what happens
            v.Set(true);
            ISet<Clause> trueClauses;
            if (formula.PruneTrueClauses(out trueClauses))
            {
                if (Solve()) return true;
                formula.RestoreClauses(trueClauses);
            }

            // Make the variable false and see what happens
            v.Set(false);
            if (formula.PruneTrueClauses(out trueClauses))
            {
                if (Solve()) return true;
                formula.RestoreClauses(trueClauses);
            }

            // Neither value worked            
            v.Clear();
            unboundVariables.Add(v);
            boundVariables.Remove(v);
            return false;
        }
    }

    class Formula
    {
        private ISet<Clause> clauses;

        public Formula()
        {
            clauses = new HashSet<Clause>();
        }

        public void AddClause(Clause c)
        {
            clauses.Add(c);
        }

        public bool PruneTrueClauses(out ISet<Clause> trueClauses)
        {
            trueClauses = new HashSet<Clause>();
            foreach (Clause c in clauses)
            {
                if (c.IsFalse()) return false;
                if (c.IsTrue()) trueClauses.Add(c);
            }
            foreach (Clause c in trueClauses)
            {
                clauses.Remove(c);
            }
            return true;
        }

        public void RestoreClauses(ISet<Clause> trueClauses)
        {
            foreach (Clause c in trueClauses)
            {
                clauses.Add(c);
            }
        }

        public Variable ChooseVariable ()
        {
            Variable var = null;
            foreach (Clause c in clauses)
            {
                Variable v;
                int count = c.GetUnboundVariable(out v);
                if (count == 1) return v;
                else if (count == 2) var = v;
                else if (count > 0 && var == null) var = v;
            }
            return var;
        }

        public bool IsEmpty()
        {
            return clauses.Count == 0;
        }

        public override string ToString ()
        {
            string result = "";
            foreach (Clause c in clauses)
            {
                result += c + " ";
            }
            return result;
        }
    }

    class Clause
    {
        private Variable[] variables;
        private bool[] senses;
        int size = 0;

        public Clause()
        {
            variables = new Variable[3];
            senses = new bool[3];
            size = 0;
        }

        public IEnumerable<Variable> Variables ()
        {
            foreach (Variable v in variables)
            {
                yield return v;
            }
        }

        public int GetUnboundVariable (out Variable var)
        {
            int count = 0;
            var = null;
            for (int i = 0; i < size; i++)
            {
                if (variables[i].IsUnbound)
                {
                    count++;
                    var = variables[i];
                }
            }
            return count;
        }

        public void AddVar (Variable v)
        {
            variables[size] = v;
            senses[size++] = true;
        }

        public void AddNotVar(Variable v)
        {
            variables[size] = v;
            senses[size++] = false;
        }

        public bool IsTrue()
        {
            for (int i = 0; i < size; i++)
            {
                Variable v = variables[i];
                if (senses[i] && v.IsTrue) return true;
                if (!senses[i] && v.IsFalse) return true;
            }
            return false;
        }

        public bool IsFalse()
        {
            for (int i = 0; i < size; i++)
            {
                Variable v = variables[i];
                if (v.IsUnbound) return false;
                if (senses[i] && v.IsTrue) return false;
                if (!senses[i] && v.IsFalse) return false;
            }
            return true;
        }

        public override string ToString ()
        {
            string result = "(";
            for (int i = 0; i < size; i++)
            {
                if (!senses[i]) result += "!";
                result += variables[i].Name + " + ";
            }
            result = result.Substring(0, result.Length - 3);
            return result + ")";
        }
    }

    class Variable
    {
        public string Name { get; }

        public bool IsTrue
        {
            get { return value == true; }
        }

        public bool IsFalse
        {
            get { return value == false; }
        }

        public bool IsUnbound
        {
            get { return value == null; }
        }

        private bool? value;

        public Variable(string name)
        {
            Name = name;
            value = null;
        }

        public void Set(bool b)
        {
            value = b;
        }

        public void Clear()
        {
            value = null;
        }
    }
}
