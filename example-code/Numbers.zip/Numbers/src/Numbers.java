
public class Numbers
{
    public static void main (String[] args)
    {
        overflow();
        //roundoff(100);
        //longToDouble();
        //square();
    }
    
    public static void overflow ()
    {
        System.out.println("ints and longs aren't integers");
        
        System.out.println();
        int n = (1 << 15) - 1;
        System.out.println(n);
        System.out.println(n*n);
        System.out.println(n*n*n);
        
        System.out.println();
        long m = (1L << 31) - 1;
        System.out.println(m);
        System.out.println(m*m);
        System.out.println(m*m*m);
    }
    
    public static void roundoff (int n)
    {
        System.out.println("doubles and floats aren't reals");
        
        System.out.println();
        System.out.println(Float.MAX_VALUE);
        System.out.println(Float.MAX_VALUE * 2);
        System.out.println(Float.MIN_VALUE);
        System.out.println(Float.MIN_VALUE / 2);
        
        System.out.println();
        System.out.println(Double.MAX_VALUE);
        System.out.println(Double.MAX_VALUE * 2);
        System.out.println(Double.MIN_VALUE);
        System.out.println(Double.MIN_VALUE / 2);
        
        double sum1 = 0;
        for (int i = 1; i <= n; i++)
        {
            sum1 += 1.0 / i;
        }

        double sum2 = 0;
        for (int i = n; i >= 1; i--)
        {
            sum2 += 1.0 / i;
        }

        System.out.println();
        System.out.println(sum1 + " " + sum2 + " " + (sum1 - sum2));
    }
    
    public static void longToDouble ()
    {
        System.out.println("Some longs aren't doubles");
        System.out.println();
        
        for (long i = Long.MAX_VALUE; i > Long.MAX_VALUE - 10; i--)
        {
            if (i != (long) (double) i)
            {
                System.out.println(i + " " + (long) (double) i + " " + (i - (long) (double) i));
            }
        }
    }

    public static void square ()
    {
        System.out.println("Double arithmetic can't be substituted for long arithmetic");
        System.out.println();
        
        for (long i = Integer.MAX_VALUE; i > Integer.MAX_VALUE - 10; i--)
        {
            long sq = (long) Math.pow(i, 2);
            if (i * i != sq)
            {
                System.out.println(i + " " + (i * i) + " " + sq + " " + (i * i - sq));
            }
        }
    }
}
